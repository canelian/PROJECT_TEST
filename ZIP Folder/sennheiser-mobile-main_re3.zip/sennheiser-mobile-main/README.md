# sennheiser-mobile
mobile shop homepage

1. 가변 타이틀 UI
2. GNB toggle & animation
3. 검색창 열고닫기
4. 제품보기 - data fetching
5. 카테고리 메뉴
6. 상세페이지